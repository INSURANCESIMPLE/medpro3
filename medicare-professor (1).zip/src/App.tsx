import React, { useState } from 'react';
import { ActiveTab } from './types';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Hero } from './components/Hero';
import { ResourceHub } from './components/ResourceHub';
import { PlanFinder } from './components/PlanFinder';
import { TimelineCalculator } from './components/TimelineCalculator';
import { AboutPage } from './components/AboutPage';
import { InsuranceSimplifiedBanner } from './components/InsuranceSimplifiedBanner';
import { InsuranceSimplifiedModal } from './components/InsuranceSimplifiedModal';
import { AdvisorModal } from './components/AdvisorModal';
import { QRCodeModal } from './components/QRCodeModal';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [isInsuranceModalOpen, setIsInsuranceModalOpen] = useState(false);
  const [isAdvisorModalOpen, setIsAdvisorModalOpen] = useState(false);
  const [isQRCodeModalOpen, setIsQRCodeModalOpen] = useState(false);
  const [isMobilePreviewMode, setIsMobilePreviewMode] = useState(false);

  return (
    <div className={`min-h-screen bg-slate-100 text-slate-900 font-sans selection:bg-amber-300 selection:text-slate-950 flex flex-col justify-between ${
      isMobilePreviewMode ? 'max-w-[420px] mx-auto my-6 rounded-[40px] shadow-2xl border-[10px] border-slate-900 overflow-hidden ring-1 ring-slate-800' : ''
    }`}>
      
      {/* Top Banner & Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
        onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
        onOpenQRCodeModal={() => setIsQRCodeModalOpen(true)}
        isMobilePreviewMode={isMobilePreviewMode}
        setIsMobilePreviewMode={setIsMobilePreviewMode}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
        
        {activeTab === 'home' && (
          <div className="space-y-8 sm:space-y-12">
            <Hero
              setActiveTab={setActiveTab}
              onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
              onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
            />

            {/* Insurance Simplified Prominent Banner */}
            <InsuranceSimplifiedBanner
              onOpenModal={() => setIsInsuranceModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'resources' && (
          <div className="space-y-8">
            <ResourceHub
              onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
              onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
            />

            <InsuranceSimplifiedBanner
              onOpenModal={() => setIsInsuranceModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'plans' && (
          <PlanFinder
            onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
            onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
          />
        )}

        {activeTab === 'timeline' && (
          <TimelineCalculator
            onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
          />
        )}

        {activeTab === 'about' && (
          <AboutPage
            onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
            onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
          />
        )}

      </main>

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
        onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
        onOpenQRCodeModal={() => setIsQRCodeModalOpen(true)}
      />

      {/* Mobile Fixed Bottom Navigation Bar (Resource & Insurance Quick Touch Target) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenInsuranceModal={() => setIsInsuranceModalOpen(true)}
        onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
      />

      {/* Insurance Simplified Partner Modal */}
      <InsuranceSimplifiedModal
        isOpen={isInsuranceModalOpen}
        onClose={() => setIsInsuranceModalOpen(false)}
        onOpenAdvisorModal={() => setIsAdvisorModalOpen(true)}
      />

      {/* Advisor Consultation Callback Modal */}
      <AdvisorModal
        isOpen={isAdvisorModalOpen}
        onClose={() => setIsAdvisorModalOpen(false)}
      />

      {/* Mobile QR Code Modal */}
      <QRCodeModal
        isOpen={isQRCodeModalOpen}
        onClose={() => setIsQRCodeModalOpen(false)}
      />

    </div>
  );
}
